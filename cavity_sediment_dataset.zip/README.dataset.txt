# Water_Cavity > 2025-07-09 6:00am
https://universe.roboflow.com/texas-tech-university-ftyvl/water_cavity

Provided by a Roboflow user
License: CC BY 4.0

